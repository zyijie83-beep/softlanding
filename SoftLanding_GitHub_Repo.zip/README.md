# SoftLanding 安落

**The information secretary for busy lives.**  
A bilingual (EN / 中文) marketing site for SoftLanding — one monthly brief for subscriptions, charges, privacy risks and family seats.

![English homepage](docs/preview-en.jpg)
![中文首页](docs/preview-zh.jpg)

## What is in here

A static site. No build step, no framework, no backend.

- `index.html` — the one-page site
- `styles.css` — layout and identity (warm paper / ink / copper)
- `app.js` — EN / 中文 switch, mobile menu
- `privacy.html`, `terms.html` — pilot notices (EN + 中文 on the page)
- `404.html`
- `system.css`, `ui/`, `motion/`, `layout/`, `icons/` — base kit
- `favicon.svg`, `robots.txt`, `.nojekyll`

## Run locally

```bash
cd softlanding-github
python3 -m http.server 4173
# open http://127.0.0.1:4173/
```

## Put it on GitHub Pages

1. Create a new repository on GitHub (for example `softlanding-site`). Public is simplest; private repos can use Pages on paid plans.
2. Upload **the contents of this folder** to the repository root. `index.html` must sit at the root, not inside a subfolder.
   - Drag the files/folders into GitHub's web uploader, or:
     ```bash
     git init -b main
     git add .
     git commit -m "SoftLanding bilingual site"
     git remote add origin https://github.com/<your-username>/softlanding-site.git
     git push -u origin main
     ```
3. In the repository: **Settings → Pages → Build and deployment → Deploy from a branch**.
4. Branch: `main`; folder: `/ (root)`; **Save**.
5. Wait for the Pages build; the site is at:
   ```
   https://<your-username>.github.io/softlanding-site/
   ```
6. All links are relative, so the project-site subpath works. For a custom domain, add it under **Settings → Pages → Custom domain** and create the DNS records GitHub shows.

No GitHub Action is needed. `.nojekyll` is included so GitHub Pages serves the static files as-is.

## Language

The **EN / 中文** switch changes every `data-i18n` string, the document title and the meta description, and remembers the choice in `localStorage`.

Screenshot / direct link:

- `?lang=en`
- `?lang=zh`

## Before launch

- Replace `hello@softlanding.example` with the real inbox.
- Replace “Nanshan, Shenzhen” with the real district if needed.
- The product UI is a designed preview; its numbers are illustrative, not customer data.
- Confirm the pilot price and the “first 50 seats” claim before publishing.
- CTAs are `mailto:` links. Add a real waitlist form when you have a backend.
- The demo loads Google Fonts. For a privacy-first production launch, self-host Instrument Sans, DM Mono and the Chinese fonts.
- The “first 50 seats” / private beta language is a pilot claim, not a live customer count.

## License

All rights reserved. See `LICENSE.txt`. The site is public for review and deployment by the SoftLanding team; the brand, copy and interface are not open-source.
